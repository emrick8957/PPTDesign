# 页面版式库

## 1. executive_summary_dashboard

适用：核心结论总览、高层判断页。

结构：

- 顶部：结论型标题；
- 左侧：核心判断或关键数字；
- 中部：3~5 个模块化结论；
- 右侧：风险/建议/决策提示；
- 底部：页脚。

使用规则：适合一页讲清“现状、判断、风险、建议”。

## 2. two_column_comparison

适用：竞品对比、现状/目标对比、方案 A/B 对比。

结构：

- 左栏：对象 A；
- 右栏：对象 B；
- 中间：差异、箭头、结论；
- 底部：启示或行动建议。

## 3. four_quadrant_judgement

适用：领先/差距/风险/建议，或价值/难度/成熟度/优先级判断。

结构：2x2 矩阵 + 顶部结论 + 底部建议。

## 4. three_column_cards

适用：三类能力、三项问题、三阶段动作。

结构：三张并列卡片，每张卡片包含图标/小标题/要点/结论。

## 5. layered_architecture

适用：技术平台、数据治理、AI平台、安全运营、系统架构。

结构：底座层 → 平台层 → 能力层 → 应用层 → 运营层。

## 6. stack_architecture_with_right_insights

适用：复杂技术架构或体系架构。

结构：左/中部为分层架构图，右侧为关键洞察、风险或建设建议。

## 7. roadmap_timeline

适用：三阶段路线、年度规划、产品演进。

结构：横向时间轴 + 阶段目标 + 关键动作 + 里程碑。

## 8. trend_curve_with_strategy

适用：产业趋势、增长趋势、技术演进。

结构：左侧曲线/趋势图，右侧策略解读和应对动作。

## 9. ecosystem_map

适用：产业生态、伙伴体系、标准组织、平台生态。

结构：中心主体 + 周边角色 + 价值流/协同关系。

## 10. insight_panel_with_chart

适用：数据图、趋势图、对比图。

结构：主图表 + 右侧洞察卡片 + 底部结论。

## 11. risk_decision_matrix

适用：风险闭环、决策建议、资源申请。

结构：表格矩阵 + 重点风险标红 + 责任/时点/产出。

## 12. multi_module_solution_overview

适用：战略/解决方案总览、业务能力展示、多行业方案介绍。

结构：顶部结论型标题 + 中部 3~6 个模块化能力/价值卡片 + 底部一句总体收口或关键路径。

使用规则：适合一页讲清“主张、能力、价值、证明”。模块之间必须同一层级，不得混放趋势、方案、案例和决策。

## 13. left_logic_right_proof

适用：方案说明、能力证明、问题到方案转化、案例佐证页。

结构：左侧 35%~45% 放核心逻辑/问题/方法，右侧 55%~65% 放案例图、指标、产品截图或证明材料，底部给出启示。

使用规则：左侧必须是可读的判断链条，右侧必须是对左侧判断的证明，不得左右两边各讲一套。

## 14. hub_spoke_ecosystem_canvas

适用：平台生态、伙伴体系、组织协同、能力关系网。

结构：中心主体 + 环绕角色/能力/场景 + 连接线/价值流 + 右侧或底部关键洞察。

使用规则：只有当页面确实表达“中心—周边—关系”时使用；若只是能力清单，优先使用 `three_column_cards` 或 `multi_module_solution_overview`。

## 15. metric_case_showcase_grid

适用：成果展示、行业覆盖、案例背书、生态伙伴展示。

结构：顶部结论 + 左侧/上方大数字指标 + 中部案例图卡/Logo/截图网格 + 底部价值收口。

使用规则：所有数字必须有来源或标注待核验；无事实依据时只保留版式，不生成确定性指标。

## 16. image_background_section_divider

适用：封面、章节页、过渡页、愿景收口页。

结构：大图背景或半幅图 + 大标题 + 章节序号/副标题 + 极少量说明文字。

使用规则：只用于节奏切换，不承载复杂论证；标题必须简洁，避免口号堆叠。

---


## 17. 关键版式语义约束

### 17.1 `four_quadrant_judgement` 坐标有效性

- 四象限必须有真实 x/y 轴含义，且每个象限位置都能被坐标解释。
- 如果只是四类概念并列，不得使用四象限；优先使用 `three_column_cards`、`multi_module_solution_overview` 或 `layered_architecture`。
- 四象限页必须标出目标区、风险区、优先区或迁移路径之一，避免成为装饰性矩阵。

### 17.2 `stack_architecture_with_right_insights` 主图—洞察关系

- 右侧洞察栏至少承载 1 句结论 + 3 条短要点。
- 右侧洞察必须解释主图，不能另讲一套或变成备注列表。
- 主图必须表达因果、层级、流向或缺口，不能只是节点堆叠。
- 如果页面核心矛盾是“A 不等于 B”，必须在主图中显式表达该差异。

### 17.3 `three_column_cards` 并列与链路判断

- 三栏若是并列分类，可使用 `three_column_cards`。
- 三栏若存在先后、因果、递归、传导关系，必须增加箭头主线或流程线；必要时改用 `swimlane_process` / `value_chain_loop`。
- 三栏页每栏内部标签建议统一为“缺口 / 影响 / 治理”或“现状 / 风险 / 动作”，避免泛化成松散 bullet。

### 17.4 `two_column_comparison` 表格转面板规则

- 汇报中的两列对比优先做左右对比面板，而非 Excel 式大表。
- 左右两列必须有明确差异结论；不得只是平铺文字。
- 目标态、新范式或推荐侧可使用标签化关键词强化，不只依靠红字。
- 底部必须有“因此”类收口，说明对比后的管理含义或行动方向。

## 18. layout 通用区域比例与禁用组合

### 18.1 通用区域比例

- 标题区：10%~15%，承载章节标签、主标题、副标题；长标题应控制在 1~2 行，避免压缩正文。
- 主体区：75%~80%，必须有清晰网格；同页模块间距不得小于卡片内边距。
- 页脚区：约 5%，位置固定，弱化显示。
- 右侧洞察栏：普通页推荐占页面宽度 18%~28%；复杂架构页或高密度技术页可放宽到 25%~32%；绝不超过 1/3；只承载 1 句结论 + 3~4 条短要点。
- 底部结论条：仅当页面需要强收口时使用；普通页优先用窄条或弱结论区，不使用厚重红色横幅。

### 18.2 禁用组合

- 不要在同一页同时使用厚重红色底部条、多个红色卡片标题、多个红色大数字。
- `insight_panel_with_chart` 中，表格承担证据，右侧指标卡承担结论；二者不得同等强视觉。
- `three_column_cards` 中，三卡可同构但必须通过编号、关键词、轻量图标或强弱层级建立扫读路径。
- `stack_architecture_with_right_insights` 中，右侧洞察栏不得变成长段文字区；主图区和洞察区必须明确主次。

### 18.3 SWE Atlas 类技术研究报告推荐母版

- 证据页：`insight_panel_with_chart`，左/中主图表为证据，右侧指标卡或洞察栏为结论。
- 问题页：`three_column_cards`，三类问题可同构，但必须建立主次和短语化表达。
- 行动页：`stack_architecture_with_right_insights`，中部闭环/流程图为概念锚点，右侧行动栏为 3~4 条关键动作。

## 19. 生成图片反馈沉淀：页面角色语义约束

来源：生成 PPT 图片 `project/PPT_image/AI4MBSE_自动化生产系统` 与华为模板对标后的通用沉淀。以下规则只约束页面角色和版式语义，不沉淀主题专属内容。

### 19.1 阅读框架页语义约束

目录/阅读框架页不能只做章节导航，必须回答“高层应如何形成判断”。推荐使用“为什么—是什么—怎么落地—如何决策”或“判断—证据—路径—拍板”的递进结构，最后一格应承担管理收口。

### 19.2 案例证明页语义约束

`left_logic_right_proof` 与 `metric_case_showcase_grid` 不得退化为图片墙。左侧必须给出判断链，右侧图片、截图、案例只证明一个核心判断；若证据不能支撑标题，应降级为待验证样例。

### 19.3 决策建议页语义约束

`risk_decision_matrix` 页面中，拍板事项必须独立突出，表格只承载责任、资源、时点、产出和风险闭环。不得让表格吞没全页结论。推荐结构为“拍板事项卡 + 执行清单表 + 风险/责任收口”。

### 19.4 路线图阶段门槛规则

`roadmap_timeline` 必须表达阶段递进，每阶段至少包含目标、关键动作、验收产出或进入下一阶段的门槛之一。不得只是并列计划；若三阶段之间没有门槛或产出继承关系，应改为三栏行动卡而非路线图。

### 19.5 总结页最终定义规则

`image_background_section_divider` 用作总结/收口页时，应形成最终定义或最终判断框架，避免复述前文要点。推荐使用“X = 对象 + 能力 + 治理边界”或“最终要形成 A/B/C/D 四类可验收能力”。

## 20. layout_pattern × component_region 兼容表

该表是图表组件区域兼容性的文档事实源。Role A 生成 `chart_components`、Role C 校验输入时必须使用同一口径。

| layout_pattern | primary 允许区域 | supporting 允许区域 | 特殊约束 |
|---|---|---|---|
| `executive_summary_dashboard` | `main,left,right` | `left,right,top,bottom` | 同一区域不得重复 |
| `two_column_comparison` | `main,left,right` | `left,right,bottom` | left/right 必须形成对比或证据关系 |
| `four_quadrant_judgement` | `main` | `bottom` | 主矩阵必须占主图区 |
| `three_column_cards` | `main,left,right` | `left,right,bottom` | supporting 卡片不得同权抢主判断 |
| `layered_architecture` | `main` | `bottom` | 不允许另设右侧结构图 |
| `stack_architecture_with_right_insights` | `main` | `bottom` | 右侧保留洞察栏，不是图表区 |
| `roadmap_timeline` | `main` | `bottom` | supporting 只能补充门槛/证据，不得成为第二时间轴 |
| `trend_curve_with_strategy` | `main,left` | `bottom` | 右侧为策略解读，不承载独立图表 |
| `ecosystem_map` | `main` | `bottom` | supporting 不得形成第二生态中心 |
| `insight_panel_with_chart` | `main,left` | `bottom` | 右侧为洞察栏，不承载独立图表 |
| `risk_decision_matrix` | `main,left,right` | `left,right,top,bottom` | 风险与决策可主辅组合 |
| `multi_module_solution_overview` | `main,left,right` | `left,right,top,bottom` | 组件必须服务统一主张 |
| `left_logic_right_proof` | `main,right` | `right,bottom` | 左侧为逻辑链，右侧才可放证明图 |
| `hub_spoke_ecosystem_canvas` | `main` | `bottom` | 不得出现第二中心关系图 |
| `metric_case_showcase_grid` | `main,left,right` | `left,right,top,bottom` | 指标和案例必须共同证明一个判断 |
| `image_background_section_divider` | `main` | `无` | primary 只能使用 `chart_type=none` |

通用规则：

- 同页所有 `component_region` 必须唯一；
- primary 使用某区域后，supporting 不得重复占用；
- `bottom` supporting 与启用的底部结论条互斥；
- `top` 指主体区顶部，不得侵入标题区；
- 不在表中的区域组合直接 FAIL；
- `component_region` 不允许 `insight_panel`、`footer`、`title` 或自造值；
- 版式没有独立右图区域时，不得用 `right` 冒充右侧洞察栏。
